package com.pranshulgg.weather_master_app.core.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.materialkolor.dynamiccolor.ColorSpec
import com.materialkolor.rememberDynamicColorScheme
import com.pranshulgg.weather_master_app.core.prefs.LocalAppPrefs

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun WeatherMasterTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    seedColor: Color = Color.Green,
    dynamicTheme: Boolean = false,
    themeVariantType: ThemeVariantType,
    applySystemUi: Boolean = true,
    content: @Composable () -> Unit
) {
    val prefs = LocalAppPrefs.current

    val baseColorScheme = when {
        dynamicTheme && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        else -> {
            rememberDynamicColorScheme(
                seedColor = seedColor,
                isDark = darkTheme,
                specVersion = ColorSpec.SpecVersion.SPEC_2025,
                style = themeVariantType.toPaletteStyle(),
            )
        }
    }

    val colorScheme = if (darkTheme && prefs.isAmoledTheme) {
        baseColorScheme.copy(
            background = Color.Black,
            surface = Color.Black,
            surfaceContainer = Color.Black,
        )
    } else {
        baseColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        if (applySystemUi) {
            SideEffect {
                val window = (view.context as Activity).window
                WindowCompat.getInsetsController(window, view)
                    .isAppearanceLightStatusBars = !darkTheme
            }
        }
    }

    MaterialExpressiveTheme(
        colorScheme = colorScheme,
        typography = getAppTypography(useGoogleSans = prefs.isGoogleSansFlex),
        motionScheme = MotionScheme.expressive(),
        content = content
    )

}

@Composable
fun isThemeDark(): Boolean {
    val prefs = LocalAppPrefs.current

    val isDark = when (prefs.appTheme) {
        "Dark" -> true
        "Light" -> false
        "System" -> isSystemInDarkTheme()
        else -> isSystemInDarkTheme()
    }

    return isDark
}
