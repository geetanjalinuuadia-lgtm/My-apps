package com.pranshulgg.weather_master_app.core.ui.navigation

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
object NavTransitions {

    private const val FADE_IN = 550
    private const val FADE_OUT = 400

    fun enter(): EnterTransition = fadeIn(tween(FADE_IN))
//        slideInHorizontally(
//            animationSpec = tween(FADE_IN),
//            initialOffsetX = { 1 * it }
//        ) + fadeIn(tween(FADE_IN))

    fun exit(): ExitTransition = fadeOut(tween(FADE_OUT))
//        slideOutHorizontally(
//            animationSpec = tween(FADE_OUT),
//            targetOffsetX = { 1 * -it / 4 }
//        ) + fadeOut(tween(FADE_OUT))

    @OptIn(ExperimentalMaterial3ExpressiveApi::class)
    fun popEnter(): EnterTransition = fadeIn(tween(FADE_IN))
//        slideInHorizontally(
//            animationSpec = tween(FADE_IN),
//            initialOffsetX = { 1 * -it / 4 }
//        ) + fadeIn(tween(FADE_IN))

    @OptIn(ExperimentalMaterial3ExpressiveApi::class)
    fun popExit(): ExitTransition = fadeOut(tween(FADE_OUT))
//        slideOutHorizontally(
//            animationSpec = tween(FADE_OUT),
//            targetOffsetX = { 1 * it }
//        ) + fadeOut(tween(FADE_OUT))
}