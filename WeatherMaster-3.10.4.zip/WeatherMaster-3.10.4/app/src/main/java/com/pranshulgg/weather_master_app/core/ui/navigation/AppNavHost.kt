package com.pranshulgg.weather_master_app.core.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.navigation
import androidx.navigation.navArgument
import com.pranshulgg.weather_master_app.core.model.domain.weather.WeatherBlockType
import com.pranshulgg.weather_master_app.feature.alerts.AlertsScreen
import com.pranshulgg.weather_master_app.feature.apikeyconfig.ApiKeysConfigScreen
import com.pranshulgg.weather_master_app.feature.blocks.screens.SunMoonScreen
import com.pranshulgg.weather_master_app.feature.blocks.screens.airquality.AirQualityScreen
import com.pranshulgg.weather_master_app.feature.blocks.screens.humidity.HumidityScreen
import com.pranshulgg.weather_master_app.feature.blocks.screens.precipitation.RainScreen
import com.pranshulgg.weather_master_app.feature.blocks.screens.precipitation.SnowScreen
import com.pranshulgg.weather_master_app.feature.blocks.screens.pressure.PressureScreen
import com.pranshulgg.weather_master_app.feature.blocks.screens.uvindex.UvIndexScreen
import com.pranshulgg.weather_master_app.feature.blocks.screens.visibility.VisibilityScreen
import com.pranshulgg.weather_master_app.feature.blocks.screens.wind.WindScreen
import com.pranshulgg.weather_master_app.feature.daily.DailyScreen
import com.pranshulgg.weather_master_app.feature.editlocation.EditLocationScreen
import com.pranshulgg.weather_master_app.feature.main.MainScreen
import com.pranshulgg.weather_master_app.feature.search.SearchScreen
import com.pranshulgg.weather_master_app.feature.settings.SettingsScreen
import com.pranshulgg.weather_master_app.feature.settings.about.AboutScreen
import com.pranshulgg.weather_master_app.feature.settings.about.license.LicenseScreen
import com.pranshulgg.weather_master_app.feature.settings.about.privacy.PrivacyPolicyScreen
import com.pranshulgg.weather_master_app.feature.settings.about.terms.TermsConditionsScreen
import com.pranshulgg.weather_master_app.feature.settings.appearance.AppearanceScreen
import com.pranshulgg.weather_master_app.feature.settings.background.BackgroundUpdatesScreen
import com.pranshulgg.weather_master_app.feature.settings.background.WorkerInfoScreen
import com.pranshulgg.weather_master_app.feature.settings.backup.BackupScreen
import com.pranshulgg.weather_master_app.feature.settings.language.LanguageScreen
import com.pranshulgg.weather_master_app.feature.settings.notifications.NotificationsScreen
import com.pranshulgg.weather_master_app.feature.settings.sources.WeatherSourcesScreen
import com.pranshulgg.weather_master_app.feature.settings.units.UnitsScreen
import com.pranshulgg.weather_master_app.feature.shared.WeatherViewModel

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun AppNavHost(
    navController: NavHostController,
    snackbarHostState: SnackbarHostState,
) {

    Box(
        Modifier.fillMaxSize()
    ) {
        NavHost(
            navController = navController,
            startDestination = "root",
            modifier = Modifier.background(MaterialTheme.colorScheme.surfaceContainer),
            enterTransition = { NavTransitions.enter() },
            exitTransition = { NavTransitions.exit() },
            popEnterTransition = { NavTransitions.popEnter() },
            popExitTransition = { NavTransitions.popExit() }
        ) {
            navigation(
                route = "root",
                startDestination = NavRoutes.MAIN
            ) {
                composable(
                    NavRoutes.MAIN
                ) { backStackEntry ->

                    val rootEntry = remember(backStackEntry) {
                        navController.getBackStackEntry("root")
                    }
                    val weatherViewModel: WeatherViewModel = hiltViewModel(rootEntry)
                    MainScreen(navController, weatherViewModel)
                }
                composable(
                    NavRoutes.SEARCH
                ) {
                    SearchScreen(navController)
                }
                composable(
                    NavRoutes.SETTINGS
                ) {
                    SettingsScreen(navController)
                }
                composable(
                    NavRoutes.APPEARANCE
                ) {
                    AppearanceScreen(navController)
                }
                composable(
                    NavRoutes.LANGUAGE
                ) {
                    LanguageScreen(navController)
                }
                composable(
                    NavRoutes.UNITS
                ) {
                    UnitsScreen(navController)
                }
                composable(
                    NavRoutes.BACKGROUND_UPDATES
                ) {
                    BackgroundUpdatesScreen(navController)
                }
                composable(
                    NavRoutes.BACKUP_RESTORE
                ) {
                    BackupScreen(navController)
                }
                composable(
                    route = "${NavRoutes.DAILY}/{index}/{locationId}",
                    arguments = listOf(
                        navArgument("index") {
                            type = NavType.IntType
                            defaultValue = 0
                        },
                        navArgument("locationId") {
                            type = NavType.StringType
                        }
                    )
                ) { backStackEntry ->
                    val index = backStackEntry.arguments?.getInt("index") ?: 0
                    val locationId = backStackEntry.arguments?.getString("locationId")

                    val rootEntry = remember(backStackEntry) {
                        navController.getBackStackEntry("root")
                    }
                    val weatherViewModel: WeatherViewModel = hiltViewModel(rootEntry)

                    DailyScreen(navController, index, locationId!!, weatherViewModel)
                }
                composable(
                    route = "${NavRoutes.ALERTS}/{locationId}",
                    arguments = listOf(
                        navArgument("locationId") {
                            type = NavType.StringType
                        }
                    )
                ) { backStackEntry ->
                    val locationId = backStackEntry.arguments?.getString("locationId")

                    AlertsScreen(navController, locationId!!)
                }
                composable(
                    NavRoutes.ABOUT
                ) {
                    AboutScreen(navController)
                }

                composable(
                    NavRoutes.TERMS_CONDITIONS
                ) {
                    TermsConditionsScreen(navController)
                }
                composable(
                    NavRoutes.PRIVACY_POLICY
                ) {
                    PrivacyPolicyScreen(navController)
                }
                composable(
                    NavRoutes.LICENSE
                ) {
                    LicenseScreen(navController)
                }
                composable(
                    NavRoutes.SOURCES
                ) {
                    WeatherSourcesScreen(navController)
                }
                composable(
                    NavRoutes.WORKER_INFO
                ) {
                    WorkerInfoScreen(navController)
                }

                composable(
                    route = "${NavRoutes.EDIT_LOCATION}/{locationId}",
                    arguments = listOf(
                        navArgument("locationId") {
                            type = NavType.StringType
                        }
                    )
                ) { backStackEntry ->

                    val locationId = backStackEntry.arguments?.getString("locationId")

                    val rootEntry = remember(backStackEntry) {
                        navController.getBackStackEntry("root")
                    }
                    val weatherViewModel: WeatherViewModel = hiltViewModel(rootEntry)

                    EditLocationScreen(navController, locationId!!, weatherViewModel)
                }
                composable(
                    route = "{block}/{index}/{locationId}",
                    arguments = listOf(
                        navArgument("index") {
                            type = NavType.IntType
                            defaultValue = 0
                        },
                        navArgument("locationId") {
                            type = NavType.StringType
                        },
                        navArgument("block") {
                            type = NavType.StringType
                        }
                    )
                ) { backStackEntry ->
                    val index = backStackEntry.arguments?.getInt("index") ?: 0
                    val locationId = backStackEntry.arguments?.getString("locationId")!!
                    val block = backStackEntry.arguments?.getString("block")

                    when (block) {
                        NavRoutes.UV_INDEX -> UvIndexScreen(navController, index, locationId)
                        NavRoutes.HUMIDITY -> HumidityScreen(navController, index, locationId)
                        NavRoutes.VISIBILITY -> VisibilityScreen(navController, index, locationId)
                        NavRoutes.SUN_MOON -> SunMoonScreen(navController, index, locationId)
                        NavRoutes.PRESSURE -> PressureScreen(navController, index, locationId)
                        NavRoutes.WIND -> WindScreen(navController, index, locationId)
                        NavRoutes.RAIN -> RainScreen(navController, index, locationId)
                        NavRoutes.SNOW -> SnowScreen(navController, index, locationId)
                        NavRoutes.AIR_QUALITY -> AirQualityScreen(navController, index, locationId)
                    }
                }
                composable(
                    NavRoutes.API_KEYS_CONFIG
                ) {
                    ApiKeysConfigScreen(navController)
                }
                composable(
                    NavRoutes.NOTIFICATIONS
                ) {
                    NotificationsScreen(navController)
                }

            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(
                    bottom = WindowInsets.navigationBars.asPaddingValues()
                        .calculateBottomPadding()
                )
        )

    }

}
