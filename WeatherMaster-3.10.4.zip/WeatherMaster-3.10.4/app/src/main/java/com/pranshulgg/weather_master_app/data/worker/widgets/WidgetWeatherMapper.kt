package com.pranshulgg.weather_master_app.data.worker.widgets

import android.content.Context
import android.content.SharedPreferences
import com.pranshulgg.weather_master_app.core.model.domain.weather.Weather
import com.pranshulgg.weather_master_app.core.model.domain.weather.WeatherUnits
import com.pranshulgg.weather_master_app.core.model.weather.TemperatureUnit
import com.pranshulgg.weather_master_app.core.model.weather.toFroggy
import com.pranshulgg.weather_master_app.core.model.weather.toIcon
import com.pranshulgg.weather_master_app.core.model.weather.toLabel
import com.pranshulgg.weather_master_app.core.prefs.helper.PreferencesHelper
import com.pranshulgg.weather_master_app.core.utils.formatters.getCurrentTimeFor
import com.pranshulgg.weather_master_app.core.utils.formatters.to12HourTimeString
import com.pranshulgg.weather_master_app.core.utils.formatters.to24HourTimeString
import com.pranshulgg.weather_master_app.core.utils.formatters.toWeekdayString
import com.pranshulgg.weather_master_app.core.utils.weather.computing.summary.computeDaySummary
import com.pranshulgg.weather_master_app.core.utils.weather.forecast.findHourlyIndexForTime
import com.pranshulgg.weather_master_app.core.utils.weather.forecast.findMatchingDaily
import com.pranshulgg.weather_master_app.core.utils.weather.forecast.isSameDay
import com.pranshulgg.weather_master_app.widgets.model.WidgetDailyItem
import com.pranshulgg.weather_master_app.widgets.model.WidgetHourlyItem
import com.pranshulgg.weather_master_app.widgets.model.WidgetWeather
import kotlinx.serialization.json.Json
import kotlin.math.roundToInt


fun widgetWeatherMapper(
    weather: Weather,
    applicationContext: Context,
    units: WeatherUnits
): String {

    // Map everything
    val timezone = weather.location.timezone

    val currentCondition = weather.current.weatherCondition.toLabel(applicationContext)
    val currentIcon = weather.current.weatherCondition.toIcon(
        targetTimeMilli = weather.current.time,
        daily = weather.daily.firstOrNull()
    )

    val currentFrogIcon = weather.current.weatherCondition.toFroggy(
        targetTimeMilli = weather.current.time,
        daily = weather.daily.firstOrNull()
    )


    val currentTemperature = TemperatureUnit.CELSIUS.convert(
        weather.current.temperature, units.tempUnit
    )?.roundToInt()


    val hourlyStartIndex =
        findHourlyIndexForTime(weather.hourly.map { it.time }, getCurrentTimeFor(timezone))

    val is24hr = PreferencesHelper.getBool("is24HrTimeFormat") ?: true


    val daySummary = computeDaySummary(weather, applicationContext, 0, units)

    val currentUvIndex = weather.current.uvIndex?.roundToInt()

    val timeFormatter: (Long?) -> String? = {
        if (it != null) {
            if (is24hr) to24HourTimeString(it, timezone) else to12HourTimeString(it, timezone)
        } else {
            null
        }
    }

    val hourly = weather.hourly
        .drop(hourlyStartIndex)
        .take(12)
        .map {
            val temperature =
                TemperatureUnit.CELSIUS.convert(it.temperature, units.tempUnit)?.roundToInt()
            val matchingDaily = findMatchingDaily(
                it.time,
                weather.daily,
                weather.location.timezone
            )
            val formattedTime = timeFormatter(it.time)

            val icon = it.weatherCondition.toIcon(matchingDaily, it.time)

            val precipitationProbability = it.precipitationProbability

            WidgetHourlyItem(
                time = formattedTime!!,
                temp = "${temperature}°",
                conditionIcon = icon,
                precipitationProbability = precipitationProbability
            )
        }

    val daily = weather.daily
        .take(6)
        .map {
            val maxTemperature =
                TemperatureUnit.CELSIUS.convert(it.temperatureMax, units.tempUnit)?.roundToInt()
            val minTemperature =
                TemperatureUnit.CELSIUS.convert(it.temperatureMin, units.tempUnit)?.roundToInt()
            val icon = it.weatherCondition.toIcon(
                targetTimeMilli = System.currentTimeMillis()
            )

            val conditionName = it.weatherCondition.toLabel(applicationContext)

            val maxUvIndexHour = weather.hourly.drop(hourlyStartIndex)
                .takeWhile { hour -> isSameDay(hour.time, it.time, timezone) }
                .maxByOrNull { index -> index.uvIndex ?: 0.0 }

            WidgetDailyItem(
                tempMax = "${maxTemperature}°",
                tempMin = "${minTemperature}°",
                conditionIcon = icon,
                time = toWeekdayString(it.time, timezone),
                conditionName = conditionName,
                maxUvIndexAt = timeFormatter(maxUvIndexHour?.time),
                maxUvIndex = it.uvIndexMax?.roundToInt() ?: maxUvIndexHour?.uvIndex?.roundToInt()
            )
        }

    val widgetState = WidgetWeather(
        currentTemp = "${currentTemperature}°",
        hourly = hourly,
        daily = daily,
        currentCondition = currentCondition,
        uvIndex = currentUvIndex,
        currentIcon = currentIcon,
        currentFrog = currentFrogIcon,
        locationName = weather.location.name,
        summary = daySummary,
        weatherCondition = weather.current.weatherCondition
    )

    // Convert to string
    return Json.encodeToString(widgetState)
}