package com.pranshulgg.weather_master_app.feature.main.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.pranshulgg.weather_master_app.core.model.weather.WeatherCondition
import com.pranshulgg.weather_master_app.core.model.domain.weather.Weather
import com.pranshulgg.weather_master_app.core.ui.theme.isThemeDark
import com.pranshulgg.weather_master_app.core.utils.weather.cache.isWeatherDomainSafe

data class Background(
    val gradient: List<Color>,
    val scrollColor: Color
)

@Composable
fun BackgroundGradient(weather: Weather?, isScrolled: Boolean = false) {

    val isDark = isThemeDark()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(color = backgroundGradients(weather, isDark).scrollColor)
    )
    AnimatedVisibility(
        visible = !isScrolled,
        enter = fadeIn(), exit = fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        backgroundGradients(weather, isDark).gradient,
                        startY = 0f,
                        endY = 1000f
                    )
                )
        )

    }

}

private fun backgroundGradients(weather: Weather?, isDark: Boolean = true): Background {

    if (!isWeatherDomainSafe(weather)) return Colors.CLEAR_SKY_DAY

    val condition = weather?.current?.weatherCondition
    val day = weather?.daily?.firstOrNull()


    val isDay = if (day != null && day.sunrise != null && day.sunset != null) {
        weather.current.time in day.sunrise..day.sunset
    } else {
        true
    }


    val gradient = gradients(isDay, condition ?: WeatherCondition.CLEAR_SKY, isDark)


    return gradient
}

private fun gradients(
    isDay: Boolean = true,
    condition: WeatherCondition,
    isDark: Boolean = true
): Background {

    val colors = if (isDark) Colors else ColorsLight

    return when (condition) {

        WeatherCondition.CLEAR_SKY -> if (isDay) colors.CLEAR_SKY_DAY else colors.CLEAR_SKY_NIGHT

        WeatherCondition.MOSTLY_CLEAR, WeatherCondition.PARTLY_CLOUDY -> colors.MOSTLY_CLEAR_PARTLY_CLOUDY

        WeatherCondition.OVERCAST -> colors.OVERCAST

        WeatherCondition.SNOW, WeatherCondition.HEAVY_SNOW, WeatherCondition.LIGHT_SNOW, WeatherCondition.MIXED_PRECIPITATION -> colors.SNOW

        WeatherCondition.RAIN, WeatherCondition.HEAVY_RAIN, WeatherCondition.LIGHT_RAIN, WeatherCondition.SLEET, WeatherCondition.HAIL -> colors.RAIN

        WeatherCondition.FOG_HAZE -> colors.FOG_HAZE

        WeatherCondition.THUNDERSTORM -> colors.THUNDERSTORM

        else -> colors.CLEAR_SKY_DAY

    }

}

interface ColorPalette {
    val CLEAR_SKY_DAY: Background
    val CLEAR_SKY_NIGHT: Background
    val MOSTLY_CLEAR_PARTLY_CLOUDY: Background

    val OVERCAST: Background
    val SNOW: Background
    val RAIN: Background
    val FOG_HAZE: Background
    val THUNDERSTORM: Background
}

object Colors : ColorPalette {

    override val CLEAR_SKY_DAY = Background(
        gradient = listOf(Color(0xFF08579C), Color(0xFF04008e)),
        scrollColor = Color(0xFF04008e)
    )

    override val CLEAR_SKY_NIGHT = Background(
        gradient = listOf(Color(0xFF01023D), Color(0xFF162155)),
        scrollColor = Color(0xFF162155)
    )

    override val MOSTLY_CLEAR_PARTLY_CLOUDY = Background(
        gradient = listOf(Color(0xFF404558), Color(0xFF262C3D)),
        scrollColor = Color(0xFF262C3D)
    )


    override val OVERCAST = Background(
        gradient = listOf(Color(0xFF2F2F34), Color(0xFF202537)),
        scrollColor = Color(0xFF202537)
    )

    override val SNOW = Background(
        gradient = listOf(Color(0xFF171717), Color(0xFF202537)),
        scrollColor = Color(0xFF202537)
    )

    override val RAIN = Background(
        gradient = listOf(Color(0xFF242429), Color(0xFF1e2c3a)),
        scrollColor = Color(0xFF1e2c3a)
    )

    override val FOG_HAZE = Background(
        gradient = listOf(Color(0xFF191209), Color(0xFF352603)),
        scrollColor = Color(0xFF352603)
    )

    override val THUNDERSTORM = Background(
        gradient = listOf(Color(0xFF15021a), Color(0xFF4C2858)),
        scrollColor = Color(0xFF4C2858)
    )

}

private object ColorsLight : ColorPalette {

    override val CLEAR_SKY_DAY = Background(
        gradient = listOf(Color(0xFF9dceff), Color(0xFFcee5ff)),
        scrollColor = Color(0xFFcee5ff)
    )

    override val CLEAR_SKY_NIGHT = Background(
        gradient = listOf(Color(0xFF969eeb), Color(0xFFE4DFFF)),
        scrollColor = Color(0xFFE4DFFF)
    )

    override val MOSTLY_CLEAR_PARTLY_CLOUDY = Background(
        gradient = listOf(Color(0xFFc6d3e4), Color(0xFFd5e4f7)),
        scrollColor = Color(0xFFd5e4f7)
    )

    override val OVERCAST = Background(
        gradient = listOf(Color(0xFFacacad), Color(0xFFd5e4f7)),
        scrollColor = Color(0xFFd5e4f7)
    )

    override val SNOW = Background(
        gradient = listOf(Color(0xFFacacad), Color(0xFFFFFFFF)),
        scrollColor = Color(0xFFFFFFFF)
    )

    override val RAIN = Background(
        gradient = listOf(Color(0xFFaab8ca), Color(0xFFc4d3e5)),
        scrollColor = Color(0xFFc4d3e5)
    )

    override val FOG_HAZE = Background(
        gradient = listOf(Color(0xFFfacb8e), Color(0xFFfff4db)),
        scrollColor = Color(0xFFfff4db)
    )

    override val THUNDERSTORM = Background(
        gradient = listOf(Color(0xFFaab8ca), Color(0xFFf2c9ff)),
        scrollColor = Color(0xFFf2c9ff)
    )

}
