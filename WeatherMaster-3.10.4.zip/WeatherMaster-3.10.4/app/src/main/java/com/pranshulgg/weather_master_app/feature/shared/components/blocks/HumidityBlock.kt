package com.pranshulgg.weather_master_app.feature.shared.components.blocks

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.pranshulgg.weather_master_app.R
import com.pranshulgg.weather_master_app.core.model.weather.TemperatureUnit
import com.pranshulgg.weather_master_app.core.model.domain.weather.WeatherUnits
import com.pranshulgg.weather_master_app.core.model.domain.weather.Weather
import com.pranshulgg.weather_master_app.core.ui.components.Gap
import com.pranshulgg.weather_master_app.core.ui.components.Symbol
import com.pranshulgg.weather_master_app.core.ui.theme.ShadowElevation
import kotlin.math.roundToInt

@Composable
fun HumidityBlock(
    weather: Weather, units: WeatherUnits,
    onClickBlock: () -> Unit,
    isDaily: Boolean,
    dailyIndex: Int,
) {
    val color = MaterialTheme.colorScheme.inversePrimary

    val humidity = if (isDaily) weather.daily[dailyIndex].humidity?.roundToInt()
    else weather.current.humidity?.roundToInt() ?: "-"


    val dewPoint = TemperatureUnit.CELSIUS.convert(
        if (isDaily) weather.daily[dailyIndex].dewPoint else weather.current.dewPoint,
        units.tempUnit
    )?.roundToInt() ?: "?"

    val humidityDrawable = when (humidity) {
        in 0..30 -> R.drawable.humidity_seven_percent
        in 30..50 -> R.drawable.humidity_thirty_precent
        in 50..70 -> R.drawable.humidity_fifty_percent
        in 70..90 -> R.drawable.humidity_seventy_percent
        else -> R.drawable.humidity_ninety_percent
    }


    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = MaterialTheme.shapes.extraLarge,
        shadowElevation = ShadowElevation.level2,
        onClick = onClickBlock
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .aspectRatio(1f)
        ) {

            Image(
                painter = painterResource(id = humidityDrawable),
                contentDescription = "Humidity",
                modifier = Modifier
                    .matchParentSize()
                    .align(Alignment.BottomCenter),
                alignment = Alignment.BottomCenter,
                colorFilter = ColorFilter.tint(color)
            )

            Box(Modifier.align(Alignment.TopStart)) {
                Header()
            }

            Text(
                "${humidity}%",
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(horizontal = 12.dp),
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            Box(Modifier.align(Alignment.BottomStart)) {
                DewPointRow(dewPoint.toString())
            }
        }
    }
}


@Composable
private fun Header() {
    Row(
        horizontalArrangement = Arrangement.spacedBy(
            5.dp,
            alignment = Alignment.CenterHorizontally
        ),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(top = 16.dp, start = 12.dp, end = 12.dp)
    ) {
        Symbol(
            R.drawable.humidity_percentage_24px,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f),
        )
        Text(
            stringResource(R.string.weather_humidity),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f)

        )
    }
}


@Composable
private fun DewPointRow(dewPoint: String?) {


    Row(
        Modifier.padding(bottom = 12.dp, start = 12.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            color = MaterialTheme.colorScheme.primary,
            shape = CircleShape,
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(36.dp)

            ) {
                Text(
                    text = "${dewPoint ?: "?"}°",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimary
                )

            }
        }
        Gap(horizontal = 5.dp)
        Text(
            stringResource(R.string.weather_dew_point),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}