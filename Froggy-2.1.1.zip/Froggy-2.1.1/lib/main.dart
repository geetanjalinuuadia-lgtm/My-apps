import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'services/system_status_service.dart';
import 'services/update_service.dart';
import 'services/window_service.dart';
import 'state/settings_controller.dart';
import 'state/weather_controller.dart';
import 'ui/froggy_view.dart';
import 'ui/settings_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FroggyApp());
}

@pragma('vm:entry-point')
void dreamMain() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const FroggyApp(screensaver: true));
}

class FroggyApp extends StatefulWidget {
  const FroggyApp({super.key, this.screensaver = false});

  final bool screensaver;

  @override
  State<FroggyApp> createState() => _FroggyAppState();
}

class _FroggyAppState extends State<FroggyApp> {
  late final SettingsController _settings;
  late final WeatherController _weather;
  bool _isTv = false;

  @override
  void initState() {
    super.initState();
    _settings = SettingsController();
    _weather = WeatherController(
      settings: _settings,
      allowLocationPrompt: !widget.screensaver,
    );
    _settings.addListener(_applyWakelock);
    _detectTv();
    _boot();

    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  void _applyWakelock() {
    if (widget.screensaver) return;
    WindowService.setKeepAwake(_settings.settings.kioskMode);
  }

  Future<void> _detectTv() async {
    final tv = await SystemStatusService().isTelevision();
    if (mounted && tv) setState(() => _isTv = tv);
  }

  Future<void> _boot() async {
    await _settings.load();
    await _weather.init();
  }

  @override
  void dispose() {
    _settings.removeListener(_applyWakelock);
    if (!widget.screensaver) WindowService.setKeepAwake(false);
    _weather.dispose();
    _settings.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Google's Weather Frog (Froggy)",
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      builder: (context, child) {
        Widget result = Shortcuts(
          shortcuts: const <ShortcutActivator, Intent>{
            SingleActivator(LogicalKeyboardKey.select): ActivateIntent(),
            SingleActivator(LogicalKeyboardKey.gameButtonA): ActivateIntent(),
          },
          child: child!,
        );
        if (_isTv) {
          result = MediaQuery(
            data: MediaQuery.of(context)
                .copyWith(navigationMode: NavigationMode.directional),
            child: result,
          );
        }
        return result;
      },
      home: widget.screensaver
          ? ScreensaverScreen(weather: _weather, settings: _settings)
          : HomeScreen(weather: _weather, settings: _settings),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.weather, required this.settings});

  final WeatherController weather;
  final SettingsController settings;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _updates = UpdateService();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkForUpdate());
  }

  @override
  void dispose() {
    _updates.dispose();
    super.dispose();
  }

  Future<void> _checkForUpdate() async {
    if (!widget.settings.settings.checkUpdatesOnStartup) return;
    final version = await WindowService.appVersion();
    if (version == null || version.isEmpty || !mounted) return;
    final info = await _updates.check(version);
    if (info == null || !info.updateAvailable || !mounted) return;
    if (!widget.settings.settings.checkUpdatesOnStartup) return;
    if (await _updates.skippedVersion() == info.latestVersion || !mounted) {
      return;
    }
    _showUpdateDialog(info);
  }

  void _showUpdateDialog(UpdateInfo info) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Update available'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Froggy v${info.latestVersion} is available — '
                'you have v${info.currentVersion}.'),
            if (info.notes.isNotEmpty) ...[
              const SizedBox(height: 12),
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 160),
                child: SingleChildScrollView(
                  child: Text(
                    info.notes,
                    style: Theme.of(ctx).textTheme.bodySmall,
                  ),
                ),
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              _updates.skipVersion(info.latestVersion);
              Navigator.pop(ctx);
            },
            child: const Text('Skip'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Later'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(ctx);
              _startUpdate(info);
            },
            child: Text(info.apkUrl != null ? 'Update' : 'View'),
          ),
        ],
      ),
    );
  }

  Future<void> _startUpdate(UpdateInfo info) async {
    if (info.apkUrl == null) {
      await WindowService.openUrl(info.releaseUrl);
      return;
    }
    final ok = await WindowService.installUpdate(info.apkUrl!);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(ok ? 'Downloading update…' : 'Could not start the update'),
      ),
    );
  }

  void _openSettings(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) =>
          SettingsScreen(settings: widget.settings, weather: widget.weather),
    ));
  }

  KeyEventResult _handleKey(BuildContext context, KeyEvent event) {
    final k = event.logicalKey;
    final isSelect = k == LogicalKeyboardKey.select ||
        k == LogicalKeyboardKey.enter ||
        k == LogicalKeyboardKey.numpadEnter ||
        k == LogicalKeyboardKey.gameButtonA ||
        k == LogicalKeyboardKey.contextMenu;
    final isScene = k == LogicalKeyboardKey.arrowLeft ||
        k == LogicalKeyboardKey.arrowRight;
    final isRefresh = k == LogicalKeyboardKey.arrowUp ||
        k == LogicalKeyboardKey.arrowDown;
    if (!isSelect && !isScene && !isRefresh) return KeyEventResult.ignored;
    if (event is KeyDownEvent) {
      if (isSelect) {
        _openSettings(context);
      } else if (isScene) {
        widget.weather.cycleScene();
      } else {
        widget.weather.refresh();
      }
    }
    return KeyEventResult.handled;
  }

  @override
  Widget build(BuildContext context) {
    final weather = widget.weather;
    final settings = widget.settings;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Focus(
        autofocus: true,
        onKeyEvent: (node, event) => _handleKey(context, event),
        child: ListenableBuilder(
        listenable: Listenable.merge([weather, settings]),
        builder: (context, _) {
          if (!weather.ready) return const SplashScreen();
          final kiosk = settings.settings.kioskMode;
          return Stack(
            fit: StackFit.expand,
            children: [
              GestureDetector(
                onTap: weather.cycleScene,
                onDoubleTap: weather.refresh,
                onLongPress: () => _openSettings(context),
                child: RepaintBoundary(
                  child: FroggyView(
                    scene: weather.scene,
                    weather: weather.weather,
                    settings: settings.settings,
                    locationName: weather.locationName,
                  ),
                ),
              ),
              if (!kiosk)
                SafeArea(
                  child: Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: IconButton(
                        icon: const Icon(Icons.settings),
                        color: Colors.white,
                        iconSize: 28,
                        tooltip: 'Settings',
                        onPressed: () => _openSettings(context),
                      ),
                    ),
                  ),
                ),
              if (weather.loading && !kiosk)
                const Positioned(
                  top: 10,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white70,
                      ),
                    ),
                  ),
                ),
            ],
          );
        },
        ),
      ),
    );
  }
}

class ScreensaverScreen extends StatelessWidget {
  const ScreensaverScreen({
    super.key,
    required this.weather,
    required this.settings,
  });

  final WeatherController weather;
  final SettingsController settings;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: ListenableBuilder(
        listenable: Listenable.merge([weather, settings]),
        builder: (context, _) {
          if (!weather.ready) return const SplashScreen();
          return RepaintBoundary(
            child: FroggyView(
              scene: weather.scene,
              weather: weather.weather,
              settings: settings.settings,
              locationName: weather.locationName,
            ),
          );
        },
      ),
    );
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      alignment: Alignment.center,
      child: const Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 112,
            height: 112,
            child: Image(
              image: AssetImage('assets/app_icon.png'),
              filterQuality: FilterQuality.medium,
            ),
          ),
          SizedBox(height: 24),
          SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: Colors.white30,
            ),
          ),
        ],
      ),
    );
  }
}
